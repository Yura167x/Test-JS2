import PropTypes from 'prop-types';
import React from 'react';
import { connect } from 'react-redux';
import {Route} from 'react-router-dom';
import {history} from '../store/configureStore';
import {ConnectedRouter} from 'react-router-redux';
import {processesApplication} from '../reducers/app';
import App from '../components/App/CaseApp';
import DevTools from './DevTools';

class MainCompound extends React.Component {
    constructor(props) {
        super(props);
        props.dispatch(processesApplication.init());
    }
    render() {
        return (
        <div>
            <ConnectedRouter history={history}>
                <Route path="/" component={App}/>
            </ConnectedRouter>
            <DevTools />
        </div>
        );
    }
}
function mapStateToProps(state) {
    return state;
}
const Root = connect(mapStateToProps)(MainCompound);
export default Root;
MainCompound.propTypes = {
    dispatch: PropTypes.func,
    history: PropTypes.object.isRequired,
};
