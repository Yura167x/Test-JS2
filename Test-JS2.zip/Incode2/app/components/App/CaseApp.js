import { connect } from 'react-redux';
import { compose, withState, withHandlers, lifecycle } from 'recompose';
import { moneyProcedure } from '../../reducers/price';
import receptacleApi from '../../services';
import WatchApp from './WatchApp';

const mapDispatchToProps = {
    fetchPrice: moneyProcedure.fetchPrice,
    handlePriceRealTime: moneyProcedure.handlePriceRealTime,
};
const mapStateToProps = (state) => ({
    List: state.price.latest.price,
    isLoading: state.price.latest.isloading,
    isStartFetch: state.price.latest.isStartFetch,
    chartData: state.price.latest.chartData,
});
const enhancer = compose(
    connect(
        mapStateToProps,
        mapDispatchToProps,
    ),
    withState('value', 'handleTickerChange', 'APPL'),
    withState('seconds', 'handleTickerChangeTime', '2000'),
    withHandlers({
        changePrice: (props) => () => {
            props.fetchPrice(props.value);
            props.handlePriceRealTime(props.value);
        },
        changeTime: (props) => () => {
            receptacleApi.setTime(props.seconds);
        },
    }),
    lifecycle({
        componentDidMount() {
            this.props.fetchPrice(this.props.value);
        },
    }),
);
export default enhancer(WatchApp);
