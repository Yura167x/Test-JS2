import React from 'react';
import ReactDOM from 'react-dom';
import ConnectAddRoot from './containers/ConnectAdd';

ReactDOM.render(
    <ConnectAddRoot />,
    document.getElementById('root')
);
