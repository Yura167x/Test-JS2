import reducer from './decreaseValue';
import * as moneyProcedure from './moneyProcedure';

export {moneyProcedure};
export default reducer;
