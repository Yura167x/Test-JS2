import { handleActions } from '@letapp/redux-actions';
import * as actions from './moneyTransactions';

const InstalDiagrDate = [];
for ( let i = 1; i < 30; i++ ) {
    InstalDiagrDate.push(Math.round( Math.random() * 100 ));
}
const FIRST_POSITION = {
    latest: {
        price: {},
        chartData: InstalDiagrDate,
        isStartFetch: false,
        isloading: false,
        isError: false,
        error: null,
    },
};
export default handleActions({
    [actions.fetchPrice.start]: (state) => ({
        ...state,
        latest: {
            ...state.latest,
            isloading: true,
            error: null,
            isError: false, },
    }),
    [actions.fetchPrice.success]: (state, action) => ({
        ...state,
        latest: {
            ...state.latest,
            isloading: false,
            price: action.payload,
            chartData: [...state.latest.chartData, ...action.payload.price], }
    }),
    [actions.fetchPrice.error]: (state, action) => ({
        latest: {
            ...state.latest,
            isloading: false,
            error: action.payload,
            isError: true, },
    }),
    [actions.fetchPriceRealTime.start]: (state) => ({
        ...state,
        latest: {
            ...state.latest,
            isStartFetch: false,
            isloading: true,
            error: null,
            isError: false, },
    }),
    [actions.fetchPriceRealTime.success]: (state, action) => ({
        ...state,
        latest: {
            ...state.latest,
            isStartFetch: true,
            isloading: false,
            price: action.payload,
            chartData: [...state.latest.chartData, +action.payload.price], }
    }),
    [actions.fetchPriceRealTime.error]: (state, action) => ({
        ...state,
        latest: {
            ...state.latest,
            isloading: false,
            error: action.payload,
            isError: true, },
    }),
}, FIRST_POSITION);
