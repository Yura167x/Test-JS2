import * as actions from './workApplication';
import Api from '../../Api';
import receptacleApi from '../../services';
import { moneyProcedure } from '../price';

export function subscribeToSockets() {
    return async function subscribeToSocketsThunck(dispatch) {
        receptacleApi.handlePrice(() => dispatch(moneyProcedure.handlePriceRealTime()));
    };
}
export function init() {
    return async function initThunk(dispatch) {
        try {
            dispatch(actions.initialization.start());
            await Api.Price.init();
            const res = Api.Price._price;
            dispatch(actions.initialization.success(res));
            dispatch(subscribeToSockets());
        } catch (err) {
            dispatch(actions.initialization.error(console.log(err)));}
    };
}
