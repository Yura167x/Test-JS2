import { createAsyncActions } from '@letapp/redux-actions';

export const initialization = createAsyncActions(
    'app/INITIALIZATION',
);
