import reducer from './changeApplication';
import * as processesApplication from './processesApplication';

export {processesApplication};
export default reducer;
