import receptacleApi from './tickerService';
export default receptacleApi;