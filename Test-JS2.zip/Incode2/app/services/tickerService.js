import io from 'socket.io-client';

class receptacleApi {
    socket = null;
    stockInterval = 2500;
    init() {
        this.socket = io('http://localhost:4000');
        this.socket.on('connect', () => {
            console.log('connected');
        });
    }
    handlePrice(stockSymbol, cb) {
        this.socket.on(stockSymbol, (data) => {
            const res = JSON.parse(data);
            console.log(res);
            cb(res);
        });
        this.socket.emit('changeTime', this.stockInterval);
        this.socket.emit('ticker', stockSymbol); }
    setTime(handleInterval) {
        this.socket.emit('disconnect', handleInterval);
        this.stockInterval = handleInterval;
        this.socket.emit('changeTime', this.stockInterval); }
}
export default new receptacleApi();
