import * as Api from './Api';

export default Api;
